Mettez le dossier turboh à la racine du lecteur C (disque ou windows est installé)

Changer la keymaster dans EscrowDecrypter/cfx/server.cfg (sv_licenseKey)

Changer tout le config.json

Changer l'emplacement du bot dans src/commands/cfx.js ligne 190 (à chaque dossier mettez bien \\ au lieu de \)

Installer Java et NodeJS

et n'oubliez pas de mettre les intents sur votre bot (https://i.postimg.cc/Mp30QYTn/image.png)

Et pour finir n'oubliez pas de changer les messages que j'ai mis dans src/commands/cfx.js (elles commencent toutes par interaction.reply)
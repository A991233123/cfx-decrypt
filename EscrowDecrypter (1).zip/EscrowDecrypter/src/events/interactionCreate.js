const Discord = require('discord.js');
const { ActionRowBuilder, ButtonStyle, Permissions, EmbedBuilder, ButtonBuilder, ChannelType, PermissionFlagsBits, ComponentType, Events, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const config = require('../../config.json');
const discordTranscripts = require("discord-html-transcripts");

module.exports = async (client, interaction) => {
    
};
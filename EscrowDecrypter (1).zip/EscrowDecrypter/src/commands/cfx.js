const Discord = require("discord.js");
const config = require("../../config.json");
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');
const ps = require('ps-node');
var dis = false

const FOLDER_FILE = path.join(__dirname, '../../cfx/resources/dumpresource');
const FOLDER_KEY = path.join(__dirname, '../../cfx');
const director_decrypt = "C:\\turboh\\decrypt.lua"
const director_decrypt2 = "C:\\turboh\\turboh.luac"

module.exports = {
    name: "cfx",
    type: Discord.ApplicationCommandType.ChatInput,

    run: async (client, interaction) => {
        if (!interaction.member.roles.cache.has(config.roles.user)) {
            interaction.reply({ content: "Vous n'avez pas les permissions.", ephemeral: true });
            return;
        }

        try {
            if(interaction.channel.id !== config.channels.cfx){
                interaction.reply({ content: "La commande doit être faite sur le discord de LoeveDecrypt !", ephemeral: true });
                return;
            }

            if(dis===true){
                interaction.reply({ content: "Le bot est déjà en train de décrypté un fichier.", ephemeral: true });
                return;
            }
// Extrait la clé du message
            const pre = config.prefix+"cfx ";
            const key = interaction.content.slice(pre.length).trim();
            
            if (!key) {
                interaction.reply('Vous devez mettre votre clé keymaster !');
                return;
            }

// Vérifiez si les fichiers .fxap et .lua ont été joints

            const fxapAttachment = interaction.attachments.find(att => att.name.endsWith('fxap'));
            const luaAttachment = interaction.attachments.find(att => att.name.endsWith('.lua'));

            if (!fxapAttachment || !luaAttachment) {
                interaction.reply("Vous devez joindre un fichier .fxap et un fichier server.lua !");
                return;
            }
            const { default: fetch } = await import('node-fetch');

// Gérer le fichier .fxap
            dis = true;
            const fxapFilePath = path.join(FOLDER_FILE, ".fxap");
            const fxapResponse = await fetch(fxapAttachment.url);
            const fxapBuffer = await fxapResponse.arrayBuffer();
            const buffer = Buffer.from(fxapBuffer);
            fs.writeFileSync(fxapFilePath, buffer);


            // Gérer le fichier .lua
            const luaFilePath = path.join(FOLDER_FILE, "server.lua");
            const luaResponse = await fetch(luaAttachment.url);
            const luaBuffer = await luaResponse.arrayBuffer();
            const buffer2 = Buffer.from(luaBuffer);
            fs.writeFileSync(luaFilePath, buffer2);

// Ecrit la clé dans le fichier server.cfg
            const cfg = `

            endpoint_add_tcp "0.0.0.0:30120"
            endpoint_add_udp "0.0.0.0:30120"
            sv_scriptHookAllowed 0
            sv_enforceGameBuild 2699
            sv_maxclients 5
            sv_hostname "Loeve" 
            sets sv_projectName "Loeve" 
            sets sv_projectDesc "Loeve" 
            set steam_webApiKey "none"
            sv_licenseKey "${key}"

            ensure dumpresource
            `
            const serverCfgFilePath = path.join(FOLDER_KEY, 'server.cfg');
            fs.writeFileSync(serverCfgFilePath, cfg);

            interaction.reply('Je décrypte le fichier, veuillez patienter !');
            setTimeout(async () => {
                try {
                    await interaction.delete();
                } catch (error) {
                    console.error("Impossible de supprimer le message :", error);
                }
            }, 1000);
            
            function terminaProcessoFxServer() {
                return new Promise((resolve, reject) => {
                    ps.lookup({ command: 'FxServer.exe' }, (err, processi) => {
                        if (err) {
                            reject(err);
                            return;
                        }
            
                        if (processi.length > 0) {
                            exec(`taskkill /F /T /PID ${processi[0].pid}`, (error, stdout, stderr) => {
                                if (error) {
                                    reject(error);
                                } else {
                                    resolve();
                                }
                            });
                        } else {
                            resolve();
                        }
                    });
                });
            }

            async function eseguiCodice(cmd, directory) {
                await terminaProcessoFxServer();

                // Esegue il nuovo comando
                new Promise((resolve, reject) => {
                    const processo = exec(cmd, { cwd: directory }, (error, stdout, stderr) => {
                        if (error) {
                        } else {
                        }
                    });
                });

                return setTimeout(async () => { await 
                    eseguiCodice2(comando2, directory2);
                }, 3000);
                
            }

            function eliminaFile(percorsoFile) {
                return new Promise((resolve, reject) => {
                    fs.unlink(percorsoFile, (errore) => {
                        if (errore) {
                            reject(errore);
                        } else {
                            resolve();
                        }
                    });
                });
            }

            async function inviaMessaggioPrivatoConFile(userId, fileDirectory) {
                try {
                    const user = await client.users.fetch(userId);
                    
                    // Leggi il file
                    const file = fs.readFileSync(fileDirectory);
            
                    // Invia il messaggio privato con il file allegat
                    
                    await user.send({ files: [{ attachment: file, name: 'Loeve.lua' }] });
                    user.send("Ton fichier est prêt ! Oublie pas de demander a ChatGPT de nettoyer le code.");
                    eliminaFile(director_decrypt)
                    .then(() => {
                        console.log('Fichier supprimé avec succès.');
                    })
                    .catch((errore) => {
                        console.error('Erreur lors de la suppression du fichier :', errore);
                    });
                    dis = false;

                } catch (error) {
                    console.error('Erreur lors de l\'envoi du message privé:', error);
                }
            }

            async function eseguiCodice2(cmd, directory) {
                new Promise((resolve, reject) => {
                    const processo = exec(cmd, { cwd: directory }, (error, stdout, stderr) => {
                        if (error) {
                        } else {
                        }
                    });
                });
                return setTimeout(async () => { await 
                    inviaMessaggioPrivatoConFile(interaction.author.id, director_decrypt);
                }, 2500);
            }

            // Utilisation de la fonction pour exécuter le code dans le cmd dans le répertoire spécifié
            const directory = 'LeCheminDaccès';
            const comando = 'server\\FxServer.exe +exec server.cfg';

            const directory2 = 'C:\\turboh';
            const comando2 = 'java -jar unluac54.jar turboh.luac > decrypt.lua';
            
            eseguiCodice(comando, directory)
            

        } catch (error) {
            console.error(error);
            interaction.reply('Une erreur s\'est produite lors de l\'exécution de la commande.');
        }
    }
};
